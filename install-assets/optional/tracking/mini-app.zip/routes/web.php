<?php

use App\Http\Controllers\LandingController;
use App\Http\Controllers\RedirectController;
use App\Http\Controllers\RedirectDropController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', [LandingController::class, 'index'])->name('index');
Route::get('/privacy', [LandingController::class, 'privacy'])->name('privacy');
Route::get('/disclaimer', [LandingController::class, 'disclaimer'])->name('disclaimer');

Route::post('/subscribe', [LandingController::class, 'subscribe'])->name('subscribe')->middleware('throttle:1,5');
Route::post('/contact', [LandingController::class, 'contact'])->name('contact')->middleware('throttle:1,5');

Route::match(['GET', 'POST'], '/unsubscribe', [LandingController::class, 'unsubscribe'])->name('unsubscribe');

Route::where(['random' => '[A-Z0-9]+', 'optional' => '.*'])->group(function () {
    Route::get('{random}r{token}/{optional?}', [RedirectController::class, 'redirect'])->name('red');
    Route::get('{random}u{token}/{optional?}', [RedirectController::class, 'unsubscribe'])->name('unsub');
    Route::get('{random}o{token}/{optional?}', [RedirectController::class, 'open'])->name('opn');
    Route::get('{random}b{token}/{optional?}', [RedirectController::class, 'bot'])->name('bot');

    Route::get('{random}dr{token}/{optional?}', [RedirectDropController::class, 'redirect'])->name('red_drop');
    Route::get('{random}du{token}/{optional?}', [RedirectDropController::class, 'unsubscribe'])->name('unsub_drop');
    Route::get('{random}do{token}/{optional?}', [RedirectDropController::class, 'open'])->name('opn_drop');
    Route::get('{random}db{token}/{optional?}', [RedirectDropController::class, 'bot'])->name('bot_drop');
});

Route::fallback([LandingController::class, 'index']);
