composer archive --format=zip --file=mini_app -vvv
