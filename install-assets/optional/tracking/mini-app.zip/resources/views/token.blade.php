<noscript>
    <meta http-equiv="refresh" content="0;url={{ $url }}?t=1">
</noscript>
<script>
    url = "{{ $url }}";
    hash = window.location.hash.replace('#', '');
    if(hash.length > 0) {
        location.replace(url + "?t=1&d="+hash);
    } else {
        location.replace(url + "?t=1");
    }
</script>
