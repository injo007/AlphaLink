<?php

/**
 * @author
 */

namespace App;

use Illuminate\Support\Facades\Http;

class Helper
{
    const IP = '[IP]';

    const KEY = '[KEY]';

    const ID = '[ID]';

    // validate token send
    public static function validateToken(string $token): array
    {
        $data = base64_decode($token, true);
        if (empty($data)) {
            return ['status' => false, 'params' => 'https://google.com/?q=TE'];
        }
        $params = explode('-', $data);
        if (count($params) < 14) {
            return ['status' => false, 'params' => 'https://google.com/?q=PE'];
        }
        $hash = hash('adler32', "$params[0]_$params[1]_$params[2]", false);
        if ($hash != $params[13]) {
            return ['status' => false, 'params' => 'https://google.com/?q=HE'];
        }

        return ['status' => true, 'params' => $params];
    }

    // get campaign info
    public static function getCampaign(
        array $token,
        string $ip_address,
        ?string $user_agent,
        string $type = 'red'
    ): array {
        $request = Http::asJson()->post(self::IP.'/api/v1/campaign', [
            'key' => self::KEY,
            'campaign_id' => $token[0],
            'email_id' => $token[2],
            'isp_id' => $token[5],
            'token' => $token[13],
            'ip_address' => $ip_address,
            'user_agent' => $user_agent,
            'type' => $type,
        ]);
        if ($request->successful()) {
            return [
                'status' => true,
                'data' => $request->json(),
            ];
        }

        return [
            'status' => false,
            'data' => 'https://google.com/?q='.$request->body(),
        ];
    }

    // get drop info
    public static function getDrop(
        array $token,
        string $ip_address,
        ?string $user_agent,
        string $type = 'red'
    ): array {
        $request = Http::asJson()->post(self::IP.'/api/v1/drop', [
            'key' => self::KEY,
            'drop_id' => $token[0],
            'email_id' => $token[2],
            'isp_id' => $token[5],
            'token' => $token[13],
            'ip_address' => $ip_address,
            'user_agent' => $user_agent,
            'type' => $type,
        ]);
        if ($request->successful()) {
            return [
                'status' => true,
                'data' => $request->json(),
            ];
        }

        return [
            'status' => false,
            'data' => 'https://google.com/?q='.$request->body(),
        ];
    }

    // sanitize HTTP header values before stats
    private static function sanitizeHttpHeader(?string $value): ?string
    {
        if ($value === null) {
            return null;
        }
        $value = trim($value);
        $value = preg_replace('/[\x00-\x1F\x7F]/', '', $value) ?? '';

        return mb_substr($value, 0, 512);
    }

    // send campaign stats
    public static function sendStats(string $type, array $data, string $ip, ?string $userAgent, ?string $referral): bool
    {
        return self::postQuietly('/api/v1/stats', [
            'key' => self::KEY,
            'action' => $type,
            'ip_address' => $ip,
            'user_agent' => self::sanitizeHttpHeader($userAgent),
            'referral' => self::sanitizeHttpHeader($referral),
            'campaign_id' => $data[0],
            'send_id' => $data[1],
            'email_id' => $data[2],
            'type' => $data[3],
            'list_id' => $data[4],
            'isp_id' => $data[5],
            'server_id' => $data[6],
            'ip_id' => $data[7],
            'domain_id' => $data[8],
            'from_id' => $data[9],
            'subject_id' => $data[10],
            'creative_id' => $data[11],
            'token' => $data[12],
        ]);
    }

    // send drop stats
    public static function sendDropStats(string $type, array $data, string $ip, ?string $userAgent, ?string $referral): bool
    {
        return self::postQuietly('/api/v1/stats-drop', [
            'key' => self::KEY,
            'action' => $type,
            'ip_address' => $ip,
            'user_agent' => self::sanitizeHttpHeader($userAgent),
            'referral' => self::sanitizeHttpHeader($referral),
            'drop_id' => $data[0],
            'email_id' => $data[2],
            'type' => $data[3],
            'list_id' => $data[4],
            'isp_id' => $data[5],
            'server_id' => $data[6],
            'ip_id' => $data[7],
            'domain_id' => $data[8],
            'from_id' => $data[9],
            'subject_id' => $data[10],
            'creative_id' => $data[11],
            'token' => $data[12],
        ]);
    }

    // post request quietly
    public static function postQuietly(string $url, array $data): bool
    {
        foreach (['user_agent', 'referral', 'referer'] as $key) {
            if (array_key_exists($key, $data)) {
                $data[$key] = self::sanitizeHttpHeader($data[$key]);
            }
        }

        app()->terminating(function () use ($url, $data) {
            try {
                Http::asJson()
                    ->timeout(5)
                    ->connectTimeout(2)
                    ->post(self::IP.$url, $data);
            } catch (\Throwable) {
                // stats must never break the user-facing response
            }
        });

        return true;
    }
}
