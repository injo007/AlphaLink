<?php

/**
 * @author
 */

namespace App\Http\Controllers;

use App\Helper;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;

class RedirectController extends Controller
{
    // campaign redirect
    public function redirect(
        Request $request,
        string $random,
        string $token,
        ?string $option = null
    ): Response|RedirectResponse {
        if ($request->has('t')) {
            $token = $request->filled('d') ? $request->get('d') : $token;
            $info = Helper::validateToken($token);
            if (! $info['status']) {
                return response()->redirectTo($info['params']);
            }
            $info = $info['params'];

            $campaign = Helper::getCampaign($info, $request->ip(), $request->userAgent());
            if (! $campaign['status']) {
                return response()->redirectTo($campaign['data']);
            }
            Helper::sendStats('click', $info, $request->ip(), $request->userAgent(), $request->server('HTTP_REFERER'));
            $link = $campaign['data']['link'];
            $key = strtr(base64_encode('C_'.$info[0]), '+/', '-_');
            $key = str_replace('=', '', $key);
            $data = match ($campaign['data']['type']) {
                'hitpath' => sprintf('%s/%s/%s', $key, implode('-', $info), $campaign['data']['user'] ?? 'NA'),
                'cake' => sprintf('%s&s2=%s&s3=%s', $key, implode('-', $info), $campaign['data']['user'] ?? 'NA'),
                'hasoffers' => sprintf('&aff_sub=%s&aff_sub2=%s&aff_sub3=%s', $key, implode('-', $info), $campaign['data']['user'] ?? 'NA'),
                'everflow' => sprintf('?sub1=%s&sub2=%s&sub3=%s', $key, implode('-', $info), $campaign['data']['user'] ?? 'NA'),
                default => ''
            };

            return response()->redirectTo($link.$data);
        }

        return response()->view('token', [
            'url' => $request->url(),
        ]);
    }

    // campaign unsubscribe
    public function unsubscribe(
        Request $request,
        string $random,
        string $token,
        ?string $option = null
    ): Response|RedirectResponse {
        if ($request->has('t')) {
            $token = $request->filled('d') ? $request->get('d') : $token;
            $info = Helper::validateToken($token);
            if (! $info['status']) {
                return response()->redirectTo($info['params']);
            }
            $info = $info['params'];

            $campaign = Helper::getCampaign($info, $request->ip(), $request->userAgent(), 'unsub');
            if (! $campaign['status']) {
                return response()->redirectTo($campaign['data']);
            }
            Helper::sendStats('unsubscribe', $info, $request->ip(), $request->userAgent(), $request->server('HTTP_REFERER'));
            $link = $campaign['data']['link'];

            return response()->redirectTo($link);
        }

        return response()->view('token', [
            'url' => $request->url(),
        ]);
    }

    // campaign open
    public function open(Request $request, string $random, string $token, ?string $option = null)
    {
        $info = Helper::validateToken($token);
        if ($info['status']) {
            $info = $info['params'];
            Helper::sendStats('open', $info, $request->ip(), $request->userAgent(), $request->server('HTTP_REFERER'));
        }
        $img = file_get_contents(public_path('open.png'));

        return response($img)->header('Content-Type', 'image/png');
    }

    // campaign bot
    public function bot(Request $request, string $random, string $token, ?string $option = null)
    {
        $info = Helper::validateToken($token);
        if ($info['status']) {
            $info = $info['params'];
            Helper::sendStats('bot', $info, $request->ip(), $request->userAgent(), $request->server('HTTP_REFERER'));
        }

        return response('https://google.com/?q=BE');
    }
}
