<!doctype html>
<html lang="en">
<head>
    <title>UNSUBSCRIBE</title>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="apple-touch-icon" sizes="180x180" href="/favicons/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="/favicons/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="/favicons/favicon-16x16.png">
    <link rel="manifest" href="/favicons/site.webmanifest">
    <style>
        :root{--blue:#007bff;--indigo:#6610f2;--purple:#6f42c1;--pink:#e83e8c;--red:#dc3545;--orange:#fd7e14;--yellow:#ffc107;--green:#28a745;--teal:#20c997;--cyan:#17a2b8;--white:#fff;--gray:#6c757d;--gray-dark:#343a40;--primary:#007bff;--secondary:#6c757d;--success:#28a745;--info:#17a2b8;--warning:#ffc107;--danger:#dc3545;--light:#f8f9fa;--dark:#343a40;--breakpoint-xs:0;--breakpoint-sm:576px;--breakpoint-md:768px;--breakpoint-lg:992px;--breakpoint-xl:1200px;--font-family-sans-serif:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,"Noto Sans",sans-serif,"Apple Color Emoji","Segoe UI Emoji","Segoe UI Symbol","Noto Color Emoji";--font-family-monospace:SFMono-Regular,Menlo,Monaco,Consolas,"Liberation Mono","Courier New",monospace;}
        *,::after,::before{box-sizing:border-box;}
        html{font-family:sans-serif;line-height:1.15;-webkit-text-size-adjust:100%;-webkit-tap-highlight-color:transparent;}
        body{margin:0;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,"Noto Sans",sans-serif,"Apple Color Emoji","Segoe UI Emoji","Segoe UI Symbol","Noto Color Emoji";font-size:1rem;font-weight:400;line-height:1.5;color:#212529;text-align:left;background-color:#fff;}
        hr{box-sizing:content-box;height:0;overflow:visible;}
        p{margin-top:0;margin-bottom:1rem;}
        strong{font-weight:bolder;}
        small{font-size:80%;}
        a{color:#007bff;text-decoration:none;background-color:transparent;}
        a:hover{color:#0056b3;text-decoration:underline;}
        input{margin:0;font-family:inherit;font-size:inherit;line-height:inherit;}
        input{overflow:visible;}
        [type=submit]{-webkit-appearance:button;}
        [type=submit]::-moz-focus-inner{padding:0;border-style:none;}
        hr{margin-top:1rem;margin-bottom:1rem;border:0;border-top:1px solid rgba(0,0,0,.1);}
        small{font-size:80%;font-weight:400;}
        .container{width:100%;padding-right:15px;padding-left:15px;margin-right:auto;margin-left:auto;}
        @media (min-width:576px){.container{max-width:540px;}}
        @media (min-width:768px){.container{max-width:720px;}}
        @media (min-width:992px){.container{max-width:960px;}}
        @media (min-width:1200px){.container{max-width:1140px;}}
        .col-12,.col-md-4,.col-md-8{position:relative;width:100%;padding-right:15px;padding-left:15px;}
        .col-12{-ms-flex:0 0 100%;flex:0 0 100%;max-width:100%;}
        @media (min-width:768px){
            .col-md-4{-ms-flex:0 0 33.333333%;flex:0 0 33.333333%;max-width:33.333333%;}
            .col-md-8{-ms-flex:0 0 66.666667%;flex:0 0 66.666667%;max-width:66.666667%;}
        }
        .form-control{display:block;width:100%;height:calc(1.5em + .75rem + 2px);padding:.375rem .75rem;font-size:1rem;font-weight:400;line-height:1.5;color:#495057;background-color:#fff;background-clip:padding-box;border:1px solid #ced4da;border-radius:.25rem;transition:border-color .15s ease-in-out,box-shadow .15s ease-in-out;}
        .form-control::-ms-expand{background-color:transparent;border:0;}
        .form-control:focus{color:#495057;background-color:#fff;border-color:#80bdff;outline:0;box-shadow:0 0 0 .2rem rgba(0,123,255,.25);}
        .form-control::-webkit-input-placeholder{color:#6c757d;opacity:1;}
        .form-control::-moz-placeholder{color:#6c757d;opacity:1;}
        .form-control:-ms-input-placeholder{color:#6c757d;opacity:1;}
        .form-control::-ms-input-placeholder{color:#6c757d;opacity:1;}
        .form-control::placeholder{color:#6c757d;opacity:1;}
        .form-control:disabled{background-color:#e9ecef;opacity:1;}
        .form-row{display:-ms-flexbox;display:flex;-ms-flex-wrap:wrap;flex-wrap:wrap;margin-right:-5px;margin-left:-5px;}
        .form-row>[class*=col-]{padding-right:5px;padding-left:5px;}
        .btn{display:inline-block;font-weight:400;color:#212529;text-align:center;vertical-align:middle;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;background-color:transparent;border:1px solid transparent;padding:.375rem .75rem;font-size:1rem;line-height:1.5;border-radius:.25rem;transition:color .15s ease-in-out,background-color .15s ease-in-out,border-color .15s ease-in-out,box-shadow .15s ease-in-out;}
        .btn:hover{color:#212529;text-decoration:none;}
        .btn:focus{outline:0;box-shadow:0 0 0 .2rem rgba(0,123,255,.25);}
        .btn:disabled{opacity:.65;}
        .btn-secondary{color:#fff;background-color:#6c757d;border-color:#6c757d;}
        .btn-secondary:hover{color:#fff;background-color:#5a6268;border-color:#545b62;}
        .btn-secondary:focus{box-shadow:0 0 0 .2rem rgba(130,138,145,.5);}
        .btn-secondary:disabled{color:#fff;background-color:#6c757d;border-color:#6c757d;}
        .btn-info{color:#fff;background-color:#17a2b8;border-color:#17a2b8;}
        .btn-info:hover{color:#fff;background-color:#138496;border-color:#117a8b;}
        .btn-info:focus{box-shadow:0 0 0 .2rem rgba(58,176,195,.5);}
        .btn-info:disabled{color:#fff;background-color:#17a2b8;border-color:#17a2b8;}
        .btn-block{display:block;width:100%;}
        input[type=submit].btn-block{width:100%;}
        .card{position:relative;display:-ms-flexbox;display:flex;-ms-flex-direction:column;flex-direction:column;min-width:0;word-wrap:break-word;background-color:#fff;background-clip:border-box;border:1px solid rgba(0,0,0,.125);border-radius:.25rem;}
        .card-body{-ms-flex:1 1 auto;flex:1 1 auto;padding:1.25rem;}
        .bg-light{background-color:#f8f9fa!important;}
        .shadow-sm{box-shadow:0 .125rem .25rem rgba(0,0,0,.075)!important;}
        .mb-2{margin-bottom:.5rem!important;}
        .mb-3{margin-bottom:1rem!important;}
        .mt-4{margin-top:1.5rem!important;}
        .text-muted{color:#6c757d!important;}
        .container {max-width:576px}
        .box-shadow-none {outline:none;-webkit-box-shadow:none!important;-moz-box-shadow:none!important;box-shadow:none!important}
        .mt-3 {margin-top:1rem!important}
        ul{list-style-type:none;padding:0}
    </style>
</head>
<body class="bg-light">
<div class="container">
    <div class="card shadow-sm mt-4">
        <div class="card-body">
            <?php if(session('info')): ?>
                <ul>
                    <li style="color: #449d44;"><?php echo e(session('info')); ?></li>
                </ul>
            <?php endif; ?>
            <?php if($errors->any()): ?>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li style="color: #b02a37"><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <?php endif; ?>

            <p>ENTER YOUR EMAIL TO UNSUBSCRIBE</p>

            <form id="unsubscribe" method="post">
                <?php echo csrf_field(); ?>
                <div class="form-row mt-3">
                    <div class="col-12">
                        <input id="email" type="text" name="email" class="form-control box-shadow-none" placeholder="Your Email">
                    </div>
                    <div class="col-12 mt-3">
                        <input class="btn btn-block btn-info" type="submit" value="UNSUBSCRIBE NOW">
                    </div>
                </div>
            </form>

            <br>

            <a href="mailto:<?php echo e('abuse@'.$site); ?>?subject=unsubscribe immediately&body=unsubscribe immediately">
                Still receiving email after unsubscribing?
            </a>
        </div>
    </div>
</div>
<script>
    const f = document.getElementById("unsubscribe");
    const i = document.getElementById("email");
    f.addEventListener("submit", function(e) {
        if (!/\S+@\S+\.\S+/.test(i.value)) {
            alert("Please enter a valid email address.");
            e.preventDefault();
        }
    });
</script>
</body>
</html>

<?php /**PATH /Users/mohamed/Desktop/work/mini_app/resources/views/unsubscribe.blade.php ENDPATH**/ ?>