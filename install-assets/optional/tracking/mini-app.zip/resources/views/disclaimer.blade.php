<div id="main">
    <div id="right">
        <table class="bordegris" cellspacing="0" cellpadding="0" width="350px" align="center" border="0">
            <tbody>
            <tr>
                <td valign="top">
                    <table cellspacing="0" cellpadding="0" width="100%" border="0">
                        <tbody>
                        <tr>
                            <td valign="top" height="200">
                                <p align="center" style="text-align:center"><b><span lang="EN-US" style="font-size:
                        8.5pt;font-family:Verdana;color:#333333">DISCLAIMER POLICY<br>
                        <br>
                        OF<br>
                        <br>
                        {{ $site }} and all related Websites.<br>
                        <br><br>
                      Last updated {{ $date }}.</span></b><span lang="EN-US" style="font-size:8.5pt;
                    font-family:Verdana;color:#333333"></span></p><span lang="EN-US"
                                                                        style="font-size:8.5pt;font-family:Verdana;color:#333333">

                                <strong>{{ $site }} </strong> serves as an informational service only. The inclusion of a link
                                    on this web site does not imply <strong>{{ $site }} </strong> endorsement of the linked site
                                    nor does<strong> {{ $site }} </strong> accept any responsibility for the content, or the use,
                                    of such site. <br><br><br>

                                <strong>{{ $site }} </strong><strong> </strong>is not responsible for the offers
                                    or goods supplied by vendors. <strong>{{ $site }} </strong>has no control over the legality of
                                    any coupons or other offers made by vendors, the ability of any of the vendors to complete the
                                    sales or transactions in accordance with the offers, or the quality of the goods offered by the
                                    vendors. In the event you have a dispute with a vendor in any way relating to this site or the
                                    use of information from this site, you agree to waive and release<strong> {{ $site }} </strong>
                                    from any and all claims, demands, actions, damages (actual and consequential), losses, costs and
                                    expenses of every kind and nature, known and unknown, disclosed and undisclosed relating to that
                                    dispute. <br><br><br>

                                It is your responsibility to verify independently that any merchant you are doing
                                    business with is legitimate and reputable. Before participating in any specific offers and/or
                                    promotions, please analyze the details and conditions of the offer including the fine print. Any
                                    access to or use of this site shall be deemed your agreement to and approval of all the above
                                    terms and conditions. <br><br><br>

                                <strong>{{ $site }} </strong><strong> </strong>and the<strong>
                                        {{ $site }} </strong> service, and all materials and information contained on it, and any
                                    services or products provided through it are provided &quot;AS IS&quot; without warranties of
                                    any kind, express or implied, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTY OF
                                    MERCHANTABILITY, fitness for a particular purpose, expectation of privacy (unless discussed on
                                    our Privacy Policy) or non-infringement. any warranty for information. <br/>

                                <strong>{{ $site }} </strong><strong> </strong>is not responsible for any
                                    damages, including without limitation, any special, indirect, incidental or consequential
                                    damages, that may arise from any use of, inability to use, or reliance on the site and/or the
                                    materials contained on the site whether the materials contained on the site are provided by
                                    the<strong> {{ $site }} </strong>, or a third party. <br/><br><br>

                                The above disclaimer of liability applies to any damages or injury caused by any
                                    error, omission, deletion, defect, interruption, failure of performance, delay in operation or
                                    transmission, computer virus, communication line failure, theft or destruction or unauthorized
                                    access to, alteration of, or use of record, whether for breach of contract, negligence, tortious
                                    behavior, or under any other cause of action. <br/><br><br>

                                Information on this web site may contain technical inaccuracies or typographical
                                    errors.<strong> {{ $site }} </strong> may make updates, improvements and/or changes in the
                                    products and/or information described at any time without notice.<strong> {{ $site }} </strong>does
                                    not guarantee the accuracy or completeness of the information contained in this site. This site
                                    contains links to sites which are not maintained by<strong> {{ $site }} </strong>. We are not
                                    responsible and have no control over the content of those sites nor do we guarantee the content
                                    of such sites. All products, services, and deals mentioned by this site are provided by third
                                    parties and are subject to change without notice and are subject to restrictions, limitations,
                                    availability, conditions, and qualifications.<br/><br><br>

            If you have questions about this disclaimer, please contact us at {{ 'support@'.$site }}.<o:p></o:p></span></p>
                                <p class="MsoNormal"><span lang="EN-US" style="mso-ansi-language:EN-US"><o:p>&nbsp;</o:p></span>
                                </p>
                                <table cellspacing="0" cellpadding="5" width="100%" border="0">
                                    <tbody>
                                    <tr>
                                    </tr>
                                    </tbody>
                                </table>
                            </td>
                        </tr>
                        </tbody>
                    </table>
                </td>
            </tr>
            </tbody>
        </table>
    </div>
    <!--content ends -->
    <!--footer begins -->
</div>
