<?php

/**
 * @author
 */

namespace App\Http\Controllers;

use App\Helper;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Validator;

class LandingController extends Controller
{
    protected string $site;

    protected string $date;

    public function __construct()
    {
        $this->site = preg_replace('(^https?://)', '', url(''));
        $this->date = now()->subDays(7)->format('Y-m-d');
    }

    // index page
    public function index(): Response
    {
        return response()->view('landing', [
            'site' => $this->site,
        ]);
    }

    // subscribe
    public function subscribe(Request $request): RedirectResponse
    {
        $validator = Validator::make($request->all(), [
            'email' => ['required', 'email'],
        ]);

        if ($validator->fails()) {
            return back()->withInput()->withErrors($validator, 'subscribe');
        }

        $data = [
            'email' => $request->input('email'),
            'ip' => $request->ip(),
            'user_agent' => $request->userAgent(),
            'referer' => $request->server('HTTP_REFERER'),
        ];
        Helper::postQuietly('/api/v1/subscribe', $data);

        return back()->with('info_subscribe', 'Thank you for subscribing!');
    }

    // disclaimer policy
    public function disclaimer(): Response
    {
        return response()->view('disclaimer', [
            'site' => $this->site,
            'date' => $this->date,
        ]);
    }

    // privacy policy
    public function privacy(): Response
    {
        return response()->view('privacy', [
            'site' => $this->site,
            'date' => $this->date,
        ]);
    }

    // contact form
    public function contact(Request $request): RedirectResponse
    {
        $validator = Validator::make($request->all(), [
            'full_name' => ['required', 'string', 'max:100', 'regex:/^[\pL\s\'\-\.]+$/u'],
            'email' => ['required', 'email', 'max:255'],
            'phone' => ['required', 'string', 'max:32', 'regex:/^[\d\s\+\-\(\)\.]+$/'],
            'message' => ['required', 'string', 'max:2000'],
        ]);

        if ($validator->fails()) {
            return redirect(route('index', ['#contact']))
                ->withInput()
                ->withErrors($validator, 'contact');
        }

        $data = [
            'full_name' => $request->input('full_name'),
            'email' => $request->input('email'),
            'phone' => $request->input('phone'),
            'message' => $request->input('message'),
            'ip' => $request->ip(),
            'user_agent' => $request->userAgent(),
            'referer' => $request->server('HTTP_REFERER'),
        ];
        Helper::postQuietly('/api/v1/contact', $data);

        return redirect(route('index', ['#contact']))
            ->with('info_contact', 'Thank you for contacting us!');
    }

    // opt-out email
    public function unsubscribe(Request $request)
    {
        if ($request->isMethod('get')) {
            return response()->view('unsubscribe', [
                'site' => $this->site,
                'date' => $this->date,
            ]);
        }
        if ($request->isMethod('post')) {
            $request->validate([
                'email' => ['required', 'email'],
            ]);

            if (! $request->has('u')) {
                Helper::postQuietly('/api/v1/opt-out', [
                    'email' => $request->input('email'),
                    'ip' => $request->ip(),
                    'user_agent' => $request->userAgent(),
                    'referer' => $request->server('HTTP_REFERER'),
                ]);
            }

            return redirect()->route('unsubscribe')->with('info', 'Your request have been received. Thank you!');
        }
    }
}
