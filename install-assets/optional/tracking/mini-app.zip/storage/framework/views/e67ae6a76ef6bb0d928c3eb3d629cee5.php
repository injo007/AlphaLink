<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <title><?php echo e($site); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link href="/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="/css/materialdesignicons.min.css" rel="stylesheet" type="text/css" />
    <link href="/css/pe-icon-7-stroke.css" rel="stylesheet" type="text/css"  />
    <link href="/css/style.css" rel="stylesheet" type="text/css" />
    <link href="/css/blue.css" rel="stylesheet" type="text/css" >
</head>
<body data-bs-spy="scroll" data-bs-target="#navbar" data-bs-offset="65">
<div id="navbar">
    <nav class="navbar navbar-expand-lg fixed-top navbar-custom sticky sticky-dark">
        <div class="container">
            <!-- LOGO -->
            <a class="navbar-brand logo text-uppercase" href="#">
                <?php echo e($site); ?>

            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse"
                    aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
                <i class="mdi mdi-menu"></i>
            </button>
            <div class="collapse navbar-collapse" id="navbarCollapse">
                <ul class="navbar-nav navbar-center" id="navbar-navlist">
                    <li class="nav-item">
                        <a data-scroll href="#home" class="nav-link">Home</a>
                    </li>
                    <li class="nav-item">
                        <a data-scroll href="#services" class="nav-link">Services</a>
                    </li>
                    <li class="nav-item">
                        <a data-scroll href="#features" class="nav-link">Features</a>
                    </li>
                    <li class="nav-item">
                        <a data-scroll href="#process" class="nav-link">Process</a>
                    </li>
                    <li class="nav-item">
                        <a data-scroll href="#contact" class="nav-link">Contact</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
</div>
<section class="section bg-home home-half" id="home">
    <div class="bg-overlay"></div>
    <div class="display-table">
        <div class="home-cell-bottom">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-8 text-white text-center">
                        <h1 class="home-title">We help startups launch their products</h1>
                        <?php if(session('info_subscribe')): ?>
                            <p class="pt-3 home-desc"> <?php echo e(session('info_subscribe')); ?></p>
                        <?php endif; ?>
                        <?php if(!empty($errors)): ?>
                            <?php if(!$errors->subscribe->isEmpty()): ?>
                                    <?php $__currentLoopData = $errors->subscribe->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <p class="text-danger home-desc"><?php echo e($error); ?></p>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            <?php endif; ?>
                        <?php endif; ?>
                        <div class="text-center subscribe-form mt-5">
                            <form action="/subscribe" method="post">
                                <?php echo csrf_field(); ?>
                                <input type="email" name="email" placeholder="Email">
                                <button type="submit" class="btn btn-primary">Subscribe</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="section pt-5" id="services">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 offset-lg-2">
                <h1 class="section-title text-center">Our Services</h1>
                <div class="section-title-border mt-3"></div>
            </div>
            <!-- end col -->
        </div>
        <!-- end row -->
        <div class="row mt-4">
            <div class="col-lg-4 mt-3">
                <div class="services-box text-center hover-effect">
                    <i class="pe-7s-diamond text-primary"></i>
                    <h4 class="pt-3">Digital Design</h4>
                </div>
            </div>
            <!-- end  -->
            <div class="col-lg-4 mt-3">
                <div class="services-box text-center hover-effect">
                    <i class="pe-7s-display2 text-primary"></i>
                    <h4 class="pt-3">Unlimited Colors</h4>
                </div>
            </div>
            <!-- end col -->
            <div class="col-lg-4 mt-3">
                <div class="services-box text-center hover-effect">
                    <i class="pe-7s-piggy text-primary"></i>
                    <h4 class="pt-3">Strategy Solutions</h4>
                </div>
            </div>
            <!-- end col -->
        </div>
        <!-- end row -->
        <div class="row mt-4">
            <div class="col-lg-4 mt-3">
                <div class="services-box text-center hover-effect">
                    <i class="pe-7s-science text-primary"></i>
                    <h4 class="pt-3">Awesome Support</h4>
                </div>
            </div>
            <!-- end col -->
            <div class="col-lg-4 mt-3">
                <div class="services-box text-center hover-effect">
                    <i class="pe-7s-news-paper text-primary"></i>
                    <h4 class="pt-3">Truly Multipurpose</h4>
                </div>
            </div>
            <!-- end col -->
            <div class="col-lg-4 mt-3">
                <div class="services-box text-center hover-effect">
                    <i class="pe-7s-plane text-primary"></i>
                    <h4 class="pt-3">Easy to customize</h4>
                </div>
            </div>
            <!-- end col -->
        </div>
        <!-- end row -->
    </div>
</section>
<section class="section bg-light" id="features">
    <div class="container">
        <div class="row vertical-content">
            <div class="col-lg-5">
                <div class="features-box">
                    <h3>A digital web design studio creating modern & engaging online experiences</h3>
                    <ul class="text-muted list-unstyled mt-4 features-item-list">
                        <li class="">We put a lot of effort in design.</li>
                        <li class="">The most important ingredient of successful website.</li>
                        <li class="">Submit Your Organization.</li>
                    </ul>
                </div>
            </div>
            <div class="col-lg-7">
                <div class="features-img features-right text-end">
                    <img src="/images/online-world.svg" alt="macbook image" class="img-fluid">
                </div>
            </div>
        </div>
    </div>
</section>
<section class="section section-lg bg-web-desc">
    <div class="bg-overlay"></div>
    <div class="container">
        <div class="row">
            <div class="col-lg-12 text-center">
                <h2 class="text-white">Build your dream website today</h2>
            </div>
        </div>
    </div>
    <div class="bg-pattern-effect">
        <img src="/images/bg-pattern.png" alt="">
    </div>
</section>
<section class="section bg-light" id="process">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 offset-lg-2">
                <h1 class="section-title text-center">Work Process</h1>
                <div class="section-title-border mt-3"></div>
                <p class="section-subtitle text-muted text-center font-secondary pt-4">
                    In an ideal world this website wouldn’t exist, a client would acknowledge the importance of
                    having web copy
                </p>
            </div>
            <!-- end col -->
        </div>
        <!-- end row -->
        <div class="row">
            <div class="col-lg-6 text-center process-left-icon-1">
                <i class="pe-7s-angle-right"></i>
            </div>
            <div class="col-lg-6 text-center process-left-icon-2">
                <i class="pe-7s-angle-right"></i>
            </div>
        </div>
        <!-- end row -->
        <div class="row mt-5">
            <div class="col-lg-4 plan-line">
                <div class="text-center process-box">
                    <i class="pe-7s-pen text-primary"></i>
                    <h4 class="pt-3">Tell us what you need</h4>
                </div>
            </div>
            <!-- end col -->
            <div class="col-lg-4 plan-line">
                <div class="text-center process-box">
                    <i class="pe-7s-id text-primary"></i>
                    <h4 class="pt-3">Get free quotes</h4>
                </div>
            </div>
            <!-- end col -->
            <div class="col-lg-4">
                <div class="text-center process-box">
                    <i class="pe-7s-target text-primary"></i>
                    <h4 class="pt-3">Deliver high quality product</h4>
                </div>
            </div>
            <!-- end col -->
        </div>
        <!-- end row -->
    </div>
</section>
<section class="section section-lg bg-get-start">
    <div class="bg-overlay"></div>
    <div class="container">
        <div class="row">
            <div class="col-lg-8 offset-lg-2 text-center">
                <h1 class="get-started-title text-white">Let's Get Started</h1>
                <div class="section-title-border mt-4 bg-white"></div>
             </div>
        </div>
    </div>
    <div class="bg-pattern-effect">
        <img src="/images/bg-pattern-light.png" alt="">
    </div>
</section>
<section class="section " id="contact">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 offset-lg-2">
                <h1 class="section-title text-center">Get In Touch</h1>
                <div class="section-title-border mt-3"></div>
                <p class="section-subtitle text-muted text-center font-secondary pt-4">We thrive when coming up with
                    innovative ideas but also understand that a smart concept should be supported with <?php echo e($site); ?> measurable
                    results.</p>
            </div>
        </div>
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <?php if(!empty($errors)): ?>
                    <?php if(!$errors->contact->isEmpty()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->contact->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
                <div class="custom-form mt-4 pt-4">
                    <form method="post" action="/contact">
                        <?php echo csrf_field(); ?>
                        <?php if(session('info_contact')): ?>
                            <p class="text-success">
                                We received your message, you'll hear from us soon. Thank You!
                            </p>
                        <?php endif; ?>
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="form-group mt-2">
                                    <input name="full_name" id="full_name" type="text" class="form-control"
                                           placeholder="Your full name*" value="<?php echo e(old('full_name')); ?>" required>
                                </div>
                            </div>
                            <!-- end col -->
                            <div class="col-lg-6">
                                <div class="form-group mt-2">
                                    <input name="email" id="email" type="email" class="form-control"
                                           placeholder="Your email*" value="<?php echo e(old('email')); ?>" required>
                                </div>
                            </div>
                            <!-- end col -->
                        </div>
                        <!-- end row -->
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="form-group mt-2">
                                    <input class="form-control" id="phone" name="phone"
                                           placeholder="Your Phone Number.." value="<?php echo e(old('phone')); ?>" />
                                </div>
                            </div><!-- end col -->
                        </div><!-- end row -->
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="form-group mt-2">
                                        <textarea name="message" id="message" rows="4" class="form-control"
                                                  placeholder="Your message..."><?php echo e(old('message')); ?></textarea>
                                </div>
                            </div>
                        </div>
                        <!-- end row -->
                        <div class="row">
                            <div class="col-lg-12 text-end">
                                <input type="submit" id="submit" name="send" class="submitBnt btn btn-primary"
                                       value="Send Message">
                            </div>
                        </div>
                    </form>
                </div>
            </div><!-- end col -->
        </div><!-- end row -->
    </div>
</section>
<footer class="footer">
    <div class="container">
        <div class="row justify-content-between">
            <div class="col-lg-3 mt-4">
                <h4><?php echo e($site); ?></h4>
                <div class="text-muted mt-4">
                    <ul class="list-unstyled footer-list">
                        <li><a href="#home">Home</a></li>
                        <li><a href="#services">Services</a></li>
                        <li><a href="#features">Features</a></li>
                        <li><a href="#process">Process</a></li>
                        <li><a href="#contact">Contact us</a></li>
                    </ul>
                </div>
            </div>
            <div class="col-lg-3 mt-4">
                <h4>Information</h4>
                <div class="text-muted mt-4">
                    <ul class="list-unstyled footer-list">
                        <li>
                            <a id="privacy" href="/privacy" target="_blank">
                                Privacy Policy
                            </a>
                        </li>
                        <li>
                            <a id="terms" href="/disclaimer" target="_blank">
                                Disclaimer
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</footer>
<div class="footer-alt">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="float-start pull-none ">
                    <p class="copy-rights text-muted">
                        <?php echo e(date('Y')); ?> © <?php echo e($site); ?>

                    </p>
                </div>
                <div class="float-end pull-none ">
                    <img src="/images/payment.png" alt="payment-img" height="36" />
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
    </div>
</div>
<script src="/js/bootstrap.bundle.min.js"></script>
<script src="/js/smooth-scroll.polyfills.min.js"></script>
<script src="/js/gumshoe.polyfills.min.js"></script>
<script src="/js/app.js"></script>
</body>
</html>
<?php /**PATH /Users/mohamed/Desktop/work/mini_app/resources/views/landing.blade.php ENDPATH**/ ?>