<div id="main">
    <div id="right">
        <table class="bordegris" cellspacing="0" cellpadding="0" width="350px" align="center" border="0">
            <tbody>
            <tr>
                <td valign="top">
                    <table cellspacing="0" cellpadding="0" width="100%" border="0">
                        <tbody>
                        <tr>
                            <td valign="top" height="200">
                                <p align="center" style="text-align:center"><b><span lang="EN-US" style="font-size:
                        8.5pt;font-family:Verdana;color:#333333">PRIVACY POLICY<br>
                        <br>
                        OF<br>
                        <br>
                        {{ $site }} and all related Websites.<br>
                        <br>
                      Last updated {{ $date }}.</span></b><span lang="EN-US" style="font-size:8.5pt;
                    font-family:Verdana;color:#333333"></span></p>
                                <p><span lang="EN-US" style="font-size:8.5pt;font-family:Verdana;color:#333333">BY
                    VISITING THIS WEBSITE AND REQUESTING INFORMATION, PRODUCTS OR SERVICES THERON,
                    YOU AGREE TO BE BOUND BY THE TERMS AND CONDITIONS OF THIS PRIVACY POLICY. IF
                    YOU DO NOT AGREE WITH THE TERMS OF THIS PRIVACY POLICY, PLEASE DO NOT PROVIDE
                    ANY INFORMATION OR USE ANY OF THE SERVICES OR PRODUCTS OFFERED OR PROVIDED ON
                    ANY OF THE WEBSITES REFERRED TO IN THIS PRIVACY POLICY.<br>
                    <br>
                    PLEASE NOTE: THIS PRIVACY POLICY CHANGES FROM TIME TO TIME AND CHANGES ARE
                    EFFECTIVE UPON POSTING. PLEASE CHECK BACK FREQUENTLY FOR UPDATES AS IT IS YOUR
                    SOLE RESPONSIBILITY TO BE AWARE OF CHANGES. WE DO NOT PROVIDE NOTICES OF
                    CHANGES IN ANY MANNER OTHER THAN BY POSTING THE CHANGES AT THIS WEB SITE.<br>
                    <br>
                    This policy describes the information collection, use, and dissemination
                    practices of {{ $site }}, ("{{ $site }}") and applies to {{ $site }} collection, use,
                    storage and disclosure of information by {{ $site }} on its (a) websites, including
                    all its divisions, subsidiaries and related companies (collectively, the
                    "Websites"), (b) on various Third Party websites, and (c) to {{ $site }}other information collection, including the purchase of customer lists from
                    Third Parties. {{ $site }} is not responsible for the information collection or
                  privacy practices of Third Party websites or applications.<o:p></o:p></span></p>
                                <p align="center" style="text-align:center">
                                    <st1:state w:st="on">
                                        <st1:place w:st="on"><b><span lang="EN-US" style="font-size:8.5pt;font-family:Verdana;
                color:#333333">CALIFORNIA</span></b></st1:place>
                                    </st1:state>
                                    <b><span lang="EN-US" style="font-size:8.5pt;font-family:Verdana;color:#333333"> RESIDENTS
              PRIVACY RIGHTS</span></b><span lang="EN-US" style="font-size:8.5pt;font-family:
            Verdana;color:#333333"><o:p></o:p></span></p>
                                <p><span lang="EN-US" style="font-size:8.5pt;font-family:Verdana;color:#333333">Companies
            that collect personally identifiable information ("PII") from
            California residents and disclose such information to Third Parties (including
            affiliated entities) for marketing purposes must, in response to a request by a
            consumer, either (1) provide a list detailing the categories of information
            shared and the entities to which such information was provided, or (2) provide
            a mechanism by which a consumer may opt-out of having their information shared
            with Third Parties. We have elected the second option and you may request that
            your PII not be shared with Third Parties by sending your request, including
            your full name, email address and postal address to:   <a
                                            href="mailto:{{'contact@'.$site}}">{{'contact@'.$site}}</a>.<br><br>
            <br>
            <span class="GramE"><b>THE INFORMATION COLLECTION, USE AND DISSEMINATION
            PRACTICES OF {{ $site }}</b>.</span><br>
            <br>
            <b>1. Collection of Information</b>. <br>
            <br>
            <b>1.1 Survey Information</b>.<br>
            <br>
            {{ $site }} collects information from individuals by various methods, including, but
            not limited to, when an individual voluntarily completes a survey, order form,
            or a registration page either online or offline, or by means of online or
            offline surveys, order forms, or registration pages operated by Third Parties
            (collectively, a "Survey"). (As used herein, "online" means
            using the Internet, including the Websites, and related technologies, and
            "offline" means by methods other than online, including in person, in
            the postal mail, using telephones and cell phones, and other similar means.) In
            the Surveys, {{ $site }} or a Third Party (a "Third Party") may ask an
            individual to provide various information to {{ $site }}, which may include his or
            her name, email address, street address, zip code, telephone numbers (including
            cell phone numbers and carriers), birth date, gender, salary range, education
            and marital status, occupation, social security number, employment information,
            personal and online interests, and such other information as may be requested
            from time to time (together, "Survey Information"). {{ $site }} may also
            collect information concerning an individual from another source and uses that
            information in combination with information provided from this web site.
            Completing the Surveys is completely voluntary, and individuals are under no
            obligation to provide Survey Information to {{ $site }} or Third Party, but an
            individual may receive incentives from {{ $site }} or a Third Party in exchange for
            providing Survey Information to {{ $site }}.<br>
            <br>
            <b>1.2 Site Membership or Registration</b>.<br>
            <br>
            To the extent registration is required to receive email and possibly postal
            communications from {{ $site }}, this Privacy Policy also applies to consumers that
            have agreed to receive e-mail marketing from {{ $site }}, whether at our Website, via
            email, on Third Party websites or otherwise. We collect information in certain
            portions of our Website, where guests provide content submissions and
            suggestions or participate in interactive online activities (i.e., by way of
            responding to questions and surveys, community listings, ratings, searches and
            comparison searches, bidding, purchasing, chat, games, or bulletin boards,
            etc.). The personal profile information you submit to {{ $site }} remains your
            property, but by submitting that information to {{ $site }}, you grant {{ $site }}, the
            right to use that information for marketing purposes. {{ $site }}, may also use such
            information for content improvement and feedback purposes. We may sell the
            personal information that you supply to us and we may join together with other
            businesses to bring selected retail opportunities to our members. These
            businesses may include providers of direct marketing services and applications,
            including lookup and reference, data enhancement, suppression and validation.
            In addition, {{ $site }} reserves the right to release current or past member
            information in the event {{ $site }} believes that the membership is being or has
            been used in violation of the Rules or to commit unlawful acts, if the
            information is subpoenaed, if {{ $site }} is sold or acquired, or when {{ $site }} deems it
            necessary or appropriate. By agreeing to these terms, you hereby consent to
            disclosure of any record or communication to any Third Party when {{ $site }} in its
            sole discretion, determines the disclosure to be appropriate.<br>
            <br>
            "Subscription" occurs when an end-user registers for {{ $site }} services,
            either via registration at our website, via co-registration at a marketing
            partner's website, or via a permission pass / opt-out / no-opt mailing {{ $site }}collects personally identifiable information about our subscribers, based on:
            information gathered at the time of registration, subscriber interaction and
            response to subsequent electronic mailings and website use, information
            provided by marketing partners, and information appended from data aggregators.
            Information collected may include, but is not necessarily limited to: name,
            email address, postal address, gender, birth date, telephone number, activity,
            interests, user behavior and other demographic information. This information
            enables us to better tailor our content to subscribers' needs and to help our
            clients to promote and sell their products and services.<br>
            <br>
            <b>1.3 Third Party List Information</b>.<br>
            <br>
            {{ $site }} collects information from individuals when an individual provides
            information to a Third Party and {{ $site }} subsequently purchases, licenses, or
            otherwise acquires the information from the Third Party (the
            "Seller"). Such purchased information may include, but is not limited
            to, an individual's name, email address, street address, zip code, telephone numbers
            (including cell phone numbers and carriers), birth date, gender, salary range,
            education and marital status, occupation, industry of employment, personal and
            online interests, and such other information as the individual may have
            provided to the Seller (together, "Third Party List Information").
            When acquiring Third Party List Information, {{ $site }} seeks assurances from the
            Seller that the Seller has a right to transfer the Third Party List Information
            to {{ $site }} and that the Seller has a right to provide offers from Advertisers to
            the individuals whose personal information is included on the Seller's list.<br>
            <br>
            <b>1.4 Other Information</b>.<br>
            <br>
            Other occasions when {{ $site }} obtains information from individuals include (1)
            when an individual is making a claim for a prize or seeking to redeem an
            incentive offered by {{ $site }} or by a Third Party, (2) when an individual requests
            assistance through {{ $site }} customer service department, and (3) when an
            individual voluntarily subscribes to a service or newsletter (together,
            "Other Information").<br>
            <br>
            <b>1.5 Cookies, Web Beacons, and Other Info Collected Using Technology</b>.<br>
            <br>
            {{ $site }} currently uses cookie and web beacon technology to associate certain
            Internet-related information about an individual with information about the
            individual in our database. Additionally, {{ $site }} may use other new and evolving
            sources of information in the future (together, "Technology
            Information").<br>
            <br>
            <b>(a) Cookies</b>.<br>
            <br>
            A cookie is a small amount of data stored on the hard drive of the individual's
            computer that allows {{ $site }} to identify the individual with his or her
            corresponding data that resides in {{ $site }} database. You may read more about
            cookies at http://cookiecentral.com. Individuals who use the Websites need to
            accept cookies in order to use all of the features and functionality of the
            Websites.<br>
            <br>
            <b>(b) Web Beacons</b>.<br>
            <br>
            A web beacon is programming code that can be used to display an image on a web
            page (by using an &lt; <span class="SpellE">img</span> <span class="SpellE">src</span>="x"&gt;
            programming function -- see https://en.wikipedia.org/wiki/Web_beacon for more information), but can
            also be used to transfer an individual's unique user identification (often in
            the form of a cookie) to a database and associate the individual with
            previously acquired information about an individual in a database. This allows
            {{ $site }} to track certain websites an individual visits online. Web beacons are
            used to determine products or services an individual may be interested in, and
            to track online behavioral habits for marketing purposes. For example, {{ $site }}might place, with the consent of a Third Party website, a web beacon on the Third
            Party's website where cosmetics are sold. When Jane, an individual listed in
            {{ $site }} database, visits the cosmetic website, {{ $site }} receives notice by means of
            the web beacon that Jane visited the cosmetics site, and {{ $site }} would then
            update Jane's profile with the information that Jane is interested in
            cosmetics. {{ $site }} may thereafter present offers of cosmetic related products and
            services to Jane. In addition to using web beacons on web pages, {{ $site }} also
            uses web beacons in email messages sent to individuals listed in {{ $site }}database.<br>
            <br>
            <b>(c) New Technology</b>.<br>
            <br>
            The use of technology on the Internet, including cookies and web beacons, is
            rapidly evolving, as is {{ $site }} use of new and evolving technology. As a result,
            {{ $site }} strongly encourages individuals to revisit this policy for any updates
            regarding its use of technology.<br>
            <br>
            <b>(d) Usage Tracking</b>.<br>
            <br>
            {{ $site }} tracks information related to the electronic mailings and web pages
            viewed by users and subscribers, as well as the hyperlinks clicked by
            subscribers, while viewing our emails or visiting our websites.<br>
            <br>
            <b>(e) Log Files</b>.<br>
            <br>
            Log files are used to track and monitor subscriber usage.<br>
            <br>
            <b>(f) Optional Registration</b>.<br>
            <br>
            {{ $site }} may offer free voluntary registration to potential subscribers. During
            such registration, the subscriber is required to supply an email address and
            other personal information. This information is required if the subscriber
            wants to participate in Company services.<br>
            <br>
            <b>(g) Feedback and Inquiries</b>.<br>
            <br>
            You have the ability to contact {{ $site }} to provide us with their feedback. {{ $site }}uses this information to respond to you and analyze customer service issues.<br>
            <br>
            <b>1.6 Outside Information</b>.<br>
            <br>
            {{ $site }} may receive information about individuals from Third Parties or from
            other sources of information outside of {{ $site }} including information located in
            public databases ("Outside Information").<br>
            <br>
            <b>1.7 Individual Information</b>.<br>
            <br>
            As used herein, Individual Information means Survey Information, Third Party
            List Information, Other Information, Technology Information, and Outside
            Information, and any other information {{ $site }} gathers or receives about
            individuals.<br>
            <br>
            <b>1.8 No Information Collected from Children</b>.<br>
            <br>
            {{ $site }} will never knowingly collect any personal information about children
            under the age of 13. If {{ $site }} obtains actual knowledge that it has collected
            personal information about a child under the age of 13, that information will
            be immediately deleted from our database. Because it does not collect such
            information, {{ $site }} has no such information to use or to disclose to Third
            Parties. {{ $site }} has designed this policy in order to comply with the Children's
            Online Privacy Protection Act ("COPPA").<br>
            <br>
            <b>1.9 Credit Card Information</b>.<br>
            <br>
            {{ $site }} may in certain cases collect credit card numbers and related information,
            such as the expiration date of the card ("Credit Card Information")
            when an individual places an order from {{ $site }}. When the Credit Card Information
            is submitted to {{ $site }}, such information is encrypted and is protected with SSL
            encryption software. {{ $site }} will use the Credit Card Information for purposes of
            processing and completing the purchase transaction, and the Credit Card
            Information will be disclosed to Third Parties only as necessary to complete
            the purchase transaction.<br>
            <br>
            <b>1.10 Links to External Websites</b>.<br>
            <br>
            {{ $site }} emails and websites contain links to external websites. You will be taken
            to external websites if you click on these links. Your information may be
            passed from {{ $site }} database to the external website, and/or external database,
            for your convenience (e.g. your information may be used to pre-fill a form at a
            destination website). {{ $site }} is not responsible for the privacy practices or
            content of any external website owner. We encourage you to review the privacy
            policy of any website they visit.<br>
            <br>
            <b>2. Use of Individual Information</b>.<br>
            <br>
            <b>2.1 Discretion to Use Information</b>.<br>
            <br>
            THE COMPANY MAY USE INDIVIDUAL INFORMATION FOR ANY LEGALLY PERMISSIBLE PURPOSE
            IN COMPANY'S SOLE DISCRETION.<br>
            <br>
            The following paragraphs in Section 2 describe how {{ $site }} currently uses
            Individual Information, but {{ $site }} may change or broaden its use at any time. As
            noted below, {{ $site }} may update this policy from time to time. {{ $site }} may use
            Individual Information to provide promotional offers to individuals by means of
            email advertising, telephone marketing, direct mail marketing, online banner
            advertising, and package stuffers, among other possible uses.<br>
            <br>
            <b>2.2 Email and Unsubscribe Policy</b>.<br>
            <br>
            {{ $site }} uses Individual Information to provide promotional offers by email to
            individuals. {{ $site }} may maintain separate email lists for different purposes. If
            email recipients wish to end their email subscription from a particular list,
            they need to follow the instructions at the end of each email message to
            unsubscribe from the particular list. To unsubscribe from all {{ $site }} email
            lists, a person must send an email to http://www.{{ $site }}/unsubscribe.<br>
            <br>
            {{ $site }} unsubscribe process impacts only the future delivery of electronic
            mailings disseminated by {{ $site }} on its own behalf. You may still receive
            electronic mailings sent on behalf of Third Parties and your personal information
            may still be shared with Third Parties for use in offline marketing and data
            appends, including email appends.<br>
            <br>
            You should also note that unsubscribing from {{ $site }} electronic mailings will not
            automatically unsubscribe the subscriber's information from any Third Party
            associates and licensees of the data. Since Third Party associates and licensee
            partners maintain separate databases from {{ $site }}, and you will need to
            unsubscribe from each source individually, if desired. This allows you the
            freedom to pick and choose which subscriptions to maintain and which to
            discontinue.<br>
            <br>
            <b>2.3 Content of Email Messages</b>.<br>
            <br>
            In certain commercial email messages sent by {{ $site }}, an Advertiser's name will
            appear in the "From:" line but hitting the "Reply" button
            will cause a reply email to be sent to {{ $site }}. The "Subject:" line of
            {{ $site }} email messages will usually contain a line provided from the Advertiser
            to {{ $site }}.<br>
            <br>
            <b>2.4 Solicited Email</b>.<br>
            <br>
            {{ $site }} only sends email to individuals who have agreed on the Websites to
            receive email from {{ $site }} or to individuals who have agreed on Third Party
            websites to receive email from Third Parties. As such, {{ $site }} does not send
            unsolicited email messages. As a result, statutes requiring certain formatting
            for unsolicited email are not applicable to {{ $site }} email messages.<br>
            <br>
            <b>2.5 Targeted Advertising</b>.<br>
            <br>
            {{ $site }} uses Individual Information to target advertising to an individual. When
            an individual is using the Internet, {{ $site }} uses Technology Information (see
            also Section 2.7 below) to associate an individual with that person's
            Individual Information, and {{ $site }} attempts to show advertising for products and
            services in which the person has expressed an interest in the Surveys,
            indicated an interest by means of Technology Information, and otherwise. {{ $site }}may, at its discretion, target advertising by using email, direct mail,
            telephones, cell phones, and other means of communication to provide
            promotional offers.<br>
            <br>
            <b>2.6 Direct Mail and Telemarketing</b>.<br>
            <br>
            {{ $site }} uses Individual Information to advertise, directly or indirectly, to
            individuals using direct mail marketing or telemarketing using telephones and
            cell phones.<br>
            <br>
            <b>2.7 Use of Technology Information</b>.<br>
            <br>
            {{ $site }} uses Technology Information (1) to match a person's Survey Information
            and Third Party List Information to other categories of Individual Information
            to make and improve profiles of individuals, (2) to track a person's online
            browsing habits on the Internet, (3) to determine which areas of {{ $site }} websites
            are most frequently visited. This information helps {{ $site }} to better understand
            the online habits of individuals so that {{ $site }} can target advertising and
            promotions to them.<br>
            <br>
            <b>2.8 Profiles of Individuals</b>.<br>
            <br>
            {{ $site }} uses Individual Information to make a profile of an individual. A profile
            can be created by combining Survey Information and Third Party List Information
            with other sources of Individual Information such as information obtained from
            public databases.<br>
            <br>
            <b>2.9 Storage of Individual Information</b>.<br>
            <br>
            {{ $site }} stores the Individual Information in a database on {{ $site }} s computers. Our
            computers have security measures (such as a firewall) in place to protect
            against the loss, misuse, and alteration of the information under {{ $site }}control. Not withstanding such measures, {{ $site }} cannot guarantee that its
            security measures will prevent <span class="SpellE">{{ $site }}'s</span> computers
            from being illegally accessed, and the Individual Information on them stolen or
            altered.<br>
            <br>
            <b>3. Dissemination of Individual Information</b>.<br>
            <br>
            <b>3.1 <st1:city w:st="on"><st1:place w:st="on">Sale</st1:place></st1:city> or
            Transfer to Third Parties</b>.<br>
            <br>
            {{ $site }} MAY SELL OR TRANSFER INDIVIDUAL INFORMATION TO THIRD PARTIES FOR ANY
            PURPOSE IN {{ $site }} SOLE DISCRETION.<br>
            <br>
            <b>3.2 Order Fulfillment</b>.<br>
            <br>
            {{ $site }} will transfer Individual Information to Third Parties when necessary to
            provide a product or service that a person orders from such Third Party while
            using {{ $site }} websites or when responding to offers provided by {{ $site }}.<br>
            <br>
            <b>3.3 Legal Process</b>.<br>
            <br>
            {{ $site }} may disclose Individual Information to respond to subpoenas, court
            orders, and other legal processes.<br>
            <br>
            <b>3.4 Summary Data</b>.<br>
            <br>
            {{ $site }} may sell or transfer non-individualized information, such as summary or
            aggregated anonymous information about all persons or sub-groups of persons.<br>
            <br>
            <b>3.5 Access</b>.<br>
            <br>
            Individuals have access to their Individual Information collected to provide an
            opportunity for an individual to correct, amend, or delete such information.
            Access can be obtained by contacting contact@{{ $site }}. {{ $site }} may also grant
            advertising clients and email services providers' access to an individual's
            email address to verify the origin of the Individual Information collected.<br>
            <br>
            <b>4. Privacy Practices of Third Parties</b>.<br>
            <br>
            <b>4.1 Advertiser cookies and web beacons</b>.<br>
            <br>
            Advertising agencies, advertising networks, and other companies (together,
            "Advertisers") who place advertisements on the Websites and on the
            Internet generally may use their own cookies, web beacons, and other technology
            to collect information about individuals. {{ $site }} does not control Advertisers'
            use of such technology and {{ $site }} has no responsibility for the use of such
            technology to gather information about individuals.<br>
            <br>
            <b>4.2 Links</b>.<br>
            <br>
            The Websites and email messages sometimes contain hypertext links to the
            websites of Third Parties. {{ $site }} is not responsible for the privacy practices
            or the content of such other websites. Linked websites may contain links to
            websites maintained by Third Parties. Such links are provided for your
            convenience and reference only. {{ $site }} does not operate or control in any
            respect any information, software, products or services available on such Third
            Party websites. The inclusion of a link to a web site does not imply any
            endorsement of the services or the site, its contents, or its sponsoring
            organization.<br>
            <br>
            <b>4.3 Affiliated Companies</b>.<br>
            <br>
            {{ $site }} may disclose, transfer, and sell Individual Information to entities
            affiliated with {{ $site }} in {{ $site }} sole discretion.<br>
            <br>
            <b>5. Unsubscribe Procedures</b>.<br>
            <br>
            If you wish to discontinue receiving email messages from {{ $site }}, you have
            several options<span class="GramE">:</span><br>
            <br>
            <b>(a) Unsubscribe from one email list</b>.<br>
            <br>
            <b>(b) Unsubscribe from all of</b> {{ $site }} <b>email lists</b>.<br>
            <br>
            We reserve the right to add Individual Information to multiple lists maintained
            by {{ $site }}. To globally unsubscribe from all of {{ $site }} lists, visit http://www.{{ $site }}/unsubscribe.<br>
            <br>
            For more information about protecting your privacy, you may wish to visit: <a
                                            href="<?php echo !empty($website) ? $website : '';?>">{{ $site }}</a>.<br>
            <br>
            If you have questions about this policy, please contact us at {{ 'support@'.$site }}.<o:p></o:p></span>
                                </p>
                                <p class="MsoNormal"><span lang="EN-US" style="mso-ansi-language:EN-US"><o:p>&nbsp;</o:p></span>
                                </p>
                                <table cellspacing="0" cellpadding="5" width="100%" border="0">
                                    <tbody>
                                    <tr>
                                    </tr>
                                    </tbody>
                                </table>
                            </td>
                        </tr>
                        </tbody>
                    </table>
                </td>
            </tr>
            </tbody>
        </table>
    </div>
    <!--content ends -->
    <!--footer begins -->
</div>
